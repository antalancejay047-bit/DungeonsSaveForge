DUNGEONS SAVE EDITOR — ANDROID APK PROJECT

This project wraps the current standalone HTML save editor in an Android WebView.
It supports choosing a .sav/JSON file through Android's file picker and exporting
the edited save to the Downloads folder.

BUILD AN APK (cloud build using GitHub Actions)
1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's Actions tab.
3. Select "Build Android APK" and press "Run workflow" (or push to main).
4. Open the completed workflow run.
5. Download the "DungeonsSaveEditor-debug-apk" artifact.
6. Extract app-debug.apk on your Android phone and install it.
   Android may ask you to allow installation from that browser/file manager.

LOCAL BUILD
Open this folder in Android Studio, allow Gradle sync, then choose:
Build > Build Bundle(s) / APK(s) > Build APK(s).

NOTES
- This is an unofficial companion app, not an official Mojang/Microsoft app.
- Keep a backup of your original save.
- Exported save compatibility has not been verified in-game.
- The APK is unsigned beyond Android's normal debug signing; it is suitable for
  personal testing, not Play Store distribution.
